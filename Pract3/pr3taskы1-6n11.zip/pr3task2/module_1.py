def print_hello():
    print("hello_1")
