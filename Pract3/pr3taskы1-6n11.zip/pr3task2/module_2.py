def print_hello():
    print("hello_2")
