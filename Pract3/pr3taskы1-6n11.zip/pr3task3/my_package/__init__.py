VAR = 0

def print_VAR():
    print(VAR)

def change_VAR():
    global VAR
    VAR += 1