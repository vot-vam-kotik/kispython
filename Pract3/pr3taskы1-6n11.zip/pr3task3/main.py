import my_package

my_package.print_VAR()

my_package.VAR += 1
my_package.print_VAR()

my_package.change_VAR()
my_package.print_VAR()