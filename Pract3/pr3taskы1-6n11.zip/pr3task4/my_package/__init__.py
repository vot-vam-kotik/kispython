__all__ = ['var1', 'func1']

var1 = 5
var2 = 10

def func1():
    print('func1 called')