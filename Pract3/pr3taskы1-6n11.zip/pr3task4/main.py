from my_package import *

print(var1)
func1()

try:
    print(var2)
except Exception as err:
    print(err)