def print_from_first_module():
    print('module1')
